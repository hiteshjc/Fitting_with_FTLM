#ifndef SEARCH_IN_FILE_H
#define SEARCH_IN_FILE_H
#include<string>
void search_for(std::string str_in, std::string filename, std::string &str_ret, bool &found);
void split(std::string &str, std::string sep_char, std::string &str_bef, std::string &str_aft);

#endif

