#ifndef INFO_HEADER
#define INFO_HEADER

#include"global.h"
#include <stdlib.h>
#include "matrix.h"
using namespace std; 
class QMC_Info
{
  public:
  std::vector<RMatrix> one_rdm;
};

#endif
